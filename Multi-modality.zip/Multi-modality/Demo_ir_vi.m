close all;
clear all
clc
global rpos;
rpos = rotatePosition(80);
addpath Function
addpath source image

chosen=16;
for ii=16:chosen
    f1 = imread(['E:\Image\MSRS-main\test\vi\',num2str(ii),'.png']);
    img2 = imread(['E:\Image\MSRS-main\test\ir\',num2str(ii),'.png']);

    f1=im2double(f1);img2=im2double(img2);

    A_YUV=ConvertRGBtoYUV(f1);   
    img1=A_YUV(:,:,1); 
    if size(img2,3)>1
        img2=rgb2gray(img2);
    end


    L1=SSF(img1,img1);
    L2=SSF(img2,img2);


    D1=img1-L1;
    D2=img2-L2;

    S1 = MUSML(D1);
    S2 = MUSML(D2);

    S11= Gra(D1);S22= Gra(D2);
    S11=real(S11);S22=real(S22);

    SA=(S1).*S11;SB=(S2).*S22;

    FD = D1.*(SA./(SA+SB))+D2.*(SB./(SA+SB));


    E1=entropy(L1);
    E2=entropy(L2);
    v1 = blkproc(L1,[3 3],[1,1],@dipin); v2 = blkproc(L2,[3 3],[1,1],@dipin); 
    e1 = mean(v1(:));e2 = mean(v2(:));
    E1 = E1.*e1; E2 = E2.*e2;
    FB2 = (E1./(E1+E2)).*L1+(E2./(E1+E2)).*L2;

    F= FB2+FD;
    [row,column] = size(F);
    F_YUV=zeros(row,column,3);
    F_YUV(:,:,1)=F;
    F_YUV(:,:,2)=A_YUV(:,:,2);
    F_YUV(:,:,3)=A_YUV(:,:,3);
    FF=ConvertYUVtoRGB(F_YUV);          % final fused result    

    figure,imshow([img1,img2]);
    figure,imshow(FF);
    %imwrite(FF,['.\result\', num2str(ii),'.jpg']);

end























