function I = EC(V,IR)

lambda=0.5;
max_iter=10;

[m, n] = size(V); 
I = zeros(m, n); 
U = zeros(m, n, 2); 
rho = 1.0; 


for k = 1:max_iter
    I = (V + IR + U(:,:,1) + U(:,:,2)) / 3;
    V = (I - IR - U(:,:,1)) ./ (1 + lambda/rho);
    IR = (I - V - U(:,:,2)) ./ (1 + lambda/rho);
    U(:,:,1) = U(:,:,1) + (I - V - IR);
    U(:,:,2) = U(:,:,2) + (IR - I + V);
end