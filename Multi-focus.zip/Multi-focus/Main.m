close all;
clear all
clc
global rpos;
rpos = rotatePosition(80);
%addpath function

chosen=20;
for ii=1:chosen
    f1 = imread(['C:\图像融合(2023.6)\多模态源图像\多聚焦图像\Lytro\',num2str(2*ii-1),'.jpg']);
    f2 = imread(['C:\图像融合(2023.6)\多模态源图像\多聚焦图像\Lytro\',num2str(2*ii),'.jpg']);

    f1=im2double(f1);f2=im2double(f2);
    for i=1:3
    
    img1 = f1(:,:,i); img2 = f2(:,:,i); 
    
%%
%tic
    L1=SSF(img1,img1);
    L2=SSF(img2,img2);
    D1=img1-L1;
    D2=img2-L2;
%%
    S1 = MUSML(D1);
    S2 = MUSML(D2);
    S11= Gra(D1);S22= Gra(D2);
    S11=real(S11);S22=real(S22);
    SA=(S1).*S11;SB=(S2).*S22;
    MAP = abs(SA>SB);
    MAP=MYZX(MAP);
    FD = MAP.*D1+(1-MAP).*D2;
%%  
    E1=entropy(L1);
    E2=entropy(L2);
    v1 = blkproc(L1,[3 3],[1,1],@dipin); v2 = blkproc(L2,[3 3],[1,1],@dipin); 
    e1 = mean(v1(:));e2 = mean(v2(:));
    E1 = E1.*e1; E2 = E2.*e2;
    FB2 = (E1./(E1+E2)).*L1+(E2./(E1+E2)).*L2;
%%
    F(:,:,i)= FB2+FD;
    end
    imwrite(F,['C:\图像融合(2023.6)\红外可见光实验\多聚焦与红外\Proposed-focus\', num2str(ii),'.tif']);
end