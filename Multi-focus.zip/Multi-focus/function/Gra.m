function S = Gra(U)

    p = 0.8;  %0.8
    gamma = 0.5 * p - 1;
    c =  p * eps^gamma;
   
    u_h = [diff(U,1,2), U(:,1,:) - U(:,end,:)];  %计算不同方向的梯度
    u_v = [diff(U,1,1); U(1,:,:) - U(end,:,:)];
        
    %mu_h = c .* u_h - p .* u_h .* (u_h .* u_h + eps) .^ gamma; 
    %mu_v = c .* u_v - p .* u_v .* (u_v .* u_v + eps) .^ gamma;
    mu_h = c .* u_h -  (2.*u_h+0.01).^ p; 
    mu_v = c .* u_v -  (2.*u_v+0.01).^ p; 

    S = sqrt(mu_h.^2 + mu_v.^2);
    %figure,imshow(S,[]);