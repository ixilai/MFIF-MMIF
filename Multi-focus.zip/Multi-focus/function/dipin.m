function R = dipin(I)

dct_I = dct2(I);

%% 
% 计算水平方向的标准差
S1 = mean(std(dct_I, 0, 2));

% 计算垂直方向的标准差
S2 = mean(std(dct_I));

% 计算主对角线方向的标准差
S3 = mean(std(diag(dct_I)));

% 计算次对角线方向的标准差
S4 = mean(std(diag(fliplr(dct_I))));

S = (S1+S2+S3+S4)/4;
S1 = S1/(S+0.0001);S2 = S2/(S+0.0001);S3 = S3/(S+0.0001);S4 = S4/(S+0.0001);



%% n=3,Frequency Variation


R = var([S1,S2,S3,S4]);