function I = EC(V,IR)

lambda=0.5;
max_iter=10;
% I-V-IR二范数最小化求解
% 使用交替方向乘子法（ADMM）进行求解
%figure,imshow([IR,V]);
[m, n] = size(V); % 图像尺寸
I = zeros(m, n); % 初始值
U = zeros(m, n, 2); % 拉格朗日乘子
rho = 1.0; % ADMM步长

% 迭代求解
for k = 1:max_iter
    % 更新I
    I = (V + IR + U(:,:,1) + U(:,:,2)) / 3;
    % 更新V
    V = (I - IR - U(:,:,1)) ./ (1 + lambda/rho);
    % 更新IR
    IR = (I - V - U(:,:,2)) ./ (1 + lambda/rho);
    % 更新拉格朗日乘子
    U(:,:,1) = U(:,:,1) + (I - V - IR);
    U(:,:,2) = U(:,:,2) + (IR - I + V);
end