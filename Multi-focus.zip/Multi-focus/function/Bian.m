function wtbi1 = Bian(img)

    wtbi1 = ones(size(img));
    sigma = 2.5;
    wtbo1 = OriGrad_MD(img, sigma);
    wtbi1 = min(wtbo1, wtbi1);
   