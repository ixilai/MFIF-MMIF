function R = MUSML(I)
    nlev = 3; scale = 0.8;  % nlev=11
    [G,L]=pyramid(I, nlev, scale);
    R=G{size(G,1)};
    for l=size(G,1)-1:-1:1

        % upsample
        R = imresize(R,[size(G{l},1),size(G{l},2)], 'bilinear');
        RG = calcFocusMeasure_new(G{l}, 3, 'SF');

        % laplacian
        RL = calcFocusMeasure_new(L{l}, 3, 'SF');
        R = sqrt(RG+RL)+R;
        %figure,imshow(R,[]);
        
        %R_out = SML(R_lap);
    end

end
