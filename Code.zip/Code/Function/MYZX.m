function cp = MYZX(midmap1)

[row,column]=size(midmap1);
v=round(log2(max(row,column)*14))+3;
T=17;%17
window_size=T; %17
[row,column]=size(midmap1);
cp=zeros(row,column);
spread=(window_size-1)/2;
map_en=padarray(midmap1,[spread spread],'symmetric');
for i=1:row
    for j=1:column
        window=map_en(i:1:(i+window_size-1),j:1:(j+window_size-1));
        judge=window.*ones(window_size,window_size);
         KA(i,j)=sum(judge(:));
    end
end
window_size=T-14; %3
for i=1:row
    for j=1:column
        window=map_en(i:1:(i+window_size-1),j:1:(j+window_size-1));
        judge=window.*ones(window_size,window_size);
        KB(i,j)=sum(judge(:));
        
    end
end
for i=1:row
    for j=1:column
        if KA(i,j)-KB(i,j)>=v*v/2
            cp(i,j)=1;
        else
            cp(i,j)=0;
        end

    end
end