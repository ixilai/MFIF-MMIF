function R = dipin(I)

dct_I = dct2(I);

%% 
S1 = mean(std(dct_I, 0, 2));

S2 = mean(std(dct_I));

S3 = mean(std(diag(dct_I)));

S4 = mean(std(diag(fliplr(dct_I))));

S = (S1+S2+S3+S4)/4;
S1 = S1/(S+0.0001);S2 = S2/(S+0.0001);S3 = S3/(S+0.0001);S4 = S4/(S+0.0001);

%% n=3,Frequency Variation


R = var([S1,S2,S3,S4]);