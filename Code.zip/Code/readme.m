% This is the code for Bridging the Gap between Multi-focus and Multi-modal: A Focused Integration Framework for Multi-modal Image Fusion
%
% If you want to test our algorithm, please run the Demo.m, 
% the source images are in the source image folder, 
% the results will be saved in the results folder.
%
%
% The functions used by the algorithm are in the Function folder, 
% so be sure to add them to the Matlab path before running our algorithm!
%






